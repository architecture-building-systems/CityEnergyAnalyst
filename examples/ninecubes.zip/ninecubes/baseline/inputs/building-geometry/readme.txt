terrain needs to be a bod not only a surface, otherwise stl import does not work

Visulaization:
